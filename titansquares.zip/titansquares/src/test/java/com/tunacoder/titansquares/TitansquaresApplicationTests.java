package com.tunacoder.titansquares;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TitansquaresApplicationTests {

	@Test
	void contextLoads() {
	}

}
